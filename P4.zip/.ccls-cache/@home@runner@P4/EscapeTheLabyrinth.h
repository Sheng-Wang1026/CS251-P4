#include <utility>
#include <random>
#include <set>
#include "grid.h"
#include "maze.h"
using namespace std;

/* Change this constant to contain your full first and last name (middle is ok too).
 *
 * WARNING: Once you've set set this constant and started exploring your maze,
 * do NOT edit the value of kYourName. Changing kYourName will change which
 * maze you get back, which might invalidate all your hard work!
 */
const string kYourName = "Sheng Wang";

/* Change these constants to contain the paths out of your mazes. */
const string kPathOutOfRegularMaze = "";
const string kPathOutOfTwistyMaze = "";

bool SPELLBOOK=0;
bool POTION=0;
bool WAND=0;

void Reset(){
  SPELLBOOK=0;
  POTION=0;
  WAND=0;
} //To reset the move

bool MOVE(const MazeCell *start, const string& moves, bool check){
  if(moves=="E"){
    if(start->east){
      if(start->east->whatsHere=="Spellbook")SPELLBOOK=1;
      else if(start->east->whatsHere=="Potion")POTION=1;
      else if(start->east->whatsHere=="Wand")WAND=1;
      
      if(check){
        if(SPELLBOOK && POTION && WAND){
          Reset();
          return true;
        } else {
          Reset();
          return false;
        }
      }
      else{
        return true;
      }
    }
    else{
      return false;
    }
  }

  else if(moves=="W"){
    if(start->west){
      if(start->west->whatsHere=="Spellbook")SPELLBOOK=1;
      else if(start->west->whatsHere=="Potion")POTION=1;
      else if(start->west->whatsHere=="Wand")WAND=1;
      
      if(check){
        if(SPELLBOOK && POTION && WAND){
          Reset();
          return true;
        } else {
          Reset();
          return false;
        }
      }
      else{
        return true;
      }
    }
    else{
      return false;
    }
  }

    else if(moves=="S"){
    if(start->south){
      if(start->south->whatsHere=="Spellbook")SPELLBOOK=1;
      else if(start->south->whatsHere=="Potion")POTION=1;
      else if(start->south->whatsHere=="Wand")WAND=1;
      
      if(check){
        if(SPELLBOOK && POTION && WAND){
          Reset();
          return true;
        } else {
          Reset();
          return false;
        }
      }
      else{
        return true;
      }
    }
    else{
      return false;
    }
  }

  else if(moves=="N"){
    if(start->north){
      if(start->north->whatsHere=="Spellbook")SPELLBOOK=1;
      else if(start->north->whatsHere=="Potion")POTION=1;
      else if(start->north->whatsHere=="Wand")WAND=1;
      
      if(check){
        if(SPELLBOOK && POTION && WAND){
          Reset();
          return true;
        } else {
          Reset();
          return false;
        }
      }
      else{
        return true;
      }
    }
    else{
      return false;
    }
  }
  return false;
}

bool isPathToFreedom(MazeCell *start, const string& moves) {

  if(moves.size()==1){
    return MOVE(start, moves, 1);
  }

  else{
    if(start->whatsHere=="Spellbook")SPELLBOOK=1;
    else if(start->whatsHere=="Potion")POTION=1;
    else if(start->whatsHere=="Wand")WAND=1;

    string move_order=moves.substr(0,1);
    if(MOVE(start, move_order, 0)){
      auto new_start=start;
      if(move_order=="E")new_start=start->east;
      else if(move_order=="W")new_start=start->west;
      else if(move_order=="S")new_start=start->south;
      else if(move_order=="N")new_start=start->north;

      string new_moves=moves.substr(1,moves.size()-1);
      if(isPathToFreedom(new_start, new_moves)){
        return true;
      } else {
        Reset();
        return false;
      }
    }
    else{
      Reset();
      return false;
    }
  }
  return false; 
}
